float hunger = 100;
float hygiene = 100;
float energie = 100;

String name = "la créature"; // Hier kann der Namen eigeben (langfristig würde ich das am liebsten auch aus der csv datei nehmen und oder das man dem am anfang eingibt)
boolean verhungert = false;

String filename = "data/beduerfnisse.csv"; //Es wird warscheinlich sinn machen die entweder nach dem namen vom tier zu bennen 
                                           //oder mehrere tiere in mehreren spalten der datei zu speichern
Table table;

void setup() {
  size(680, 460);
  beduerfnisseLaden();
  textFont(createFont("DigitalDystopia-mL5ma.ttf", 255)); //Hier Die text font muss im selben order wie das programm liegen (könnte ma aber auch ändern warscheinlich)
  //würde final die font nochmal ändern jetzt zum testen passt die 
}


//Knöpfe würde ich maybe später ändern wollen das man mit der maus dinge machen muss für die bedürfnisse
void keyPressed() {
  if (verhungert) {
    if (key == 'r' || key == 'R') {
      resetSpiel();
    }
    return; 
  }
  if (key == 'f' || key == 'F') {
    hunger = min(hunger + 10, 100);
  }
  if (key == 'h' || key == 'H') {
    hygiene = min(hygiene + 10, 100);
  }
  if (key == 'e' || key == 'E') {
    energie = min(energie + 10, 100);
}}
void draw() {
  background(0);
  
  //Die bedürfnisse nach der zeit runter gehen (maybe wenn wir emotionen und so machen wollen 
  //könnte man auch noch multiplikatoren dranhänngen das die je nach emotion schneller langsama sind)
  if (!verhungert) {
    hunger = max(0, hunger - 0.1);
    hygiene = max(0, hygiene - 0.07);
    energie = max(0, energie - 0.05);
    if (hunger <= 0) {
      verhungert = true;
    }} 
    // das tier stirbt
    else {
    textAlign(CENTER, CENTER);
    fill(#ef4444);
    textSize(32);
    text(name + " ist verhungert!", width / 2, height / 2 - 20);
    fill(255);
    textSize(18);
    text("Drücke [R] zum Zurücksetzen", width / 2, height / 2 + 25);
    textAlign(LEFT, BASELINE);
  }
  //leisten mit label anzeigen
  textSize(18);
  zeichneBalken("Hunger [F]", hunger, 20, 395, #1fcfb1);
  zeichneBalken("Hygiene [H]", hygiene, 170, 395, #38bdf8);
  zeichneBalken("Energie [E]", energie, 320, 395, #facc15);
}
//fals tier stirbt werden dei bedürfnisse resettet
void resetSpiel() {
  hunger = 100;
  hygiene = 100;
  energie = 100;
  verhungert = false;
  beduerfnisseSpeichern();
}
//funktion zum galken zeichnen
void zeichneBalken(String label, float wert, float x, float y, color farbe) {
  fill(farbe);
  text(label, x, y);
  fill(100);
  rect(x, y + 8, 110, 6);
  fill(farbe);
  rect(x, y + 8, map(wert, 0, 100, 0, 110), 6);
}
//bedürfnisse aus der csv laden
void beduerfnisseLaden() {
  File f = new File(sketchPath(filename));
  if (f.exists()) {
    table = loadTable(filename, "header");
    if (table != null && table.getRowCount() > 0) {
      TableRow row = table.getRow(0);
      hunger = row.getFloat("hunger");
      hygiene = row.getFloat("hygiene");
      energie = row.getFloat("energie");
      if (hunger <= 0) {
        verhungert = true;
      }
      return;
}}
  hunger = 100;
  hygiene = 100;
  energie = 100;
}
// speichern der bedürfnisse in die csv datei
void beduerfnisseSpeichern() {
  table = new Table();
  table.addColumn("hunger");
  table.addColumn("hygiene");
  table.addColumn("energie");
  TableRow row = table.addRow();
  row.setFloat("hunger", hunger);
  row.setFloat("hygiene", hygiene);
  row.setFloat("energie", energie);
  saveTable(table, filename);
}

//wenn das spiel geschlosssen wird wird einmal gespeichert
void exit() {
  beduerfnisseSpeichern();
  super.exit();
}
